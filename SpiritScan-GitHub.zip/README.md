# SpiritScan

Sensor-driven anomaly app using **NSCB Jones HV Field v3.17** + **NSCB-v3.18-SDE** models.

Build the APK **from your phone** using GitHub Actions — no Android Studio required.

---

## How to build the APK on your phone

### 1. Create a GitHub repository
1. Open **github.com** in your phone browser (or the GitHub app).
2. Tap **+ → New repository**.
3. Name it e.g. `SpiritScan`.
4. Make it **Public** (easier for free Actions minutes).
5. Do **not** add a README (we already have one).
6. Create the repository.

### 2. Upload this project
**Easiest method (phone browser):**
1. Download the zip from this conversation.
2. Unzip it (most phone file managers can unzip).
3. On the new empty GitHub repo page → **uploading an existing file**.
4. Select **all files and folders** inside the unzipped `spirit-scan-ci` folder (or the root of the zip).
5. Commit.

**Alternative (GitHub mobile / git clients):**  
Push the entire contents of this folder to the repo root.

### 3. Trigger the build
1. Go to the **Actions** tab of your repo.
2. Select **Build APK**.
3. Tap **Run workflow** → **Run workflow**.
4. Wait 3–6 minutes.

### 4. Download the APK
1. When the workflow finishes (green check), open it.
2. Scroll to **Artifacts**.
3. Download **SpiritScan** (or SpiritScan-debug).
4. Unzip the downloaded artifact → you get `SpiritScan.apk`.
5. Install it on your phone (you may need to allow “Install from unknown sources”).

That’s it. Every time you push a change (or re-run the workflow) a fresh APK is produced.

---

## What the app does

- Reads magnetometer + accelerometer at high rate
- Feeds derived features into the real NSCB Jones + SDE ONNX models
- Shows live field state (`stable`, `firewall`, `harmonic_break`, …) and a short narrative
- Timeline of past detections

**Permissions requested:** Location, Body Sensors, Microphone (optional), Notifications.

---

## Project structure

```
app/
  src/main/
    java/com/spirit/scan/   ← all Kotlin code
    assets/models/          ← jones.onnx + sde.onnx
    AndroidManifest.xml
.github/workflows/build-apk.yml  ← the CI that builds the APK
```

Models are already included. No extra files needed.

## License

MIT License — see [LICENSE](LICENSE).
