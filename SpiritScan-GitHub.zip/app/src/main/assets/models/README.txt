Models present:

  jones.onnx   ← nscb_jones_hv_field_v3.17.onnx  (NSCB Jones HV Field)
  sde.onnx     ← nscb_v82_3_18_sde_stability_v3.18.onnx  (NSCB SDE Stability)

These are the real physics-style models, not the sequence classifiers
described in the original PDF skeletons. The Kotlin runners have been
updated to match the actual ONNX contracts.
