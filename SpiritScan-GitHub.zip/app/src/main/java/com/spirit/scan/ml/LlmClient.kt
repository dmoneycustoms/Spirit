package com.spirit.scan.ml

import android.content.Context
import android.util.Log
import com.spirit.scan.SpiritApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Narrative generator.
 *
 * Two modes:
 *  1. Remote HTTP endpoint (recommended for production) – set REMOTE_URL
 *  2. Local GGUF placeholder (you must integrate llama.cpp / MLX / etc.)
 *
 * The specification allows either "llm-quantized.gguf (or remote endpoint)".
 */
class LlmClient(private val context: Context) {

    // Change this to your own inference server, or leave null to use local stub
    private val remoteUrl: String? = null   // e.g. "https://your-server/v1/completions"

    suspend fun generate(prompt: String): String = withContext(Dispatchers.IO) {
        if (remoteUrl != null) {
            callRemote(prompt)
        } else {
            // Local stub – replace with real GGUF runner when you have the JNI/AAR
            localStub(prompt)
        }
    }

    private fun callRemote(prompt: String): String {
        return try {
            val url = URL(remoteUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            val body = """{"prompt":${prompt.escapeJson()},"max_tokens":120,"temperature":0.7}"""
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val text = conn.inputStream.bufferedReader().readText()
            if (code in 200..299) {
                // very naive extraction – adapt to your API
                text
            } else {
                Log.w(SpiritApp.TAG, "LLM remote failed $code: $text")
                "…"
            }
        } catch (e: Exception) {
            Log.e(SpiritApp.TAG, "LLM remote error", e)
            "…"
        }
    }

    /**
     * Placeholder that returns a deterministic narrative based on the prompt.
     * Replace this method with a real llama.cpp / ONNX-LLM / MediaPipe call
     * once you place llm-quantized.gguf in assets/models/ and add the native lib.
     */
    private fun localStub(prompt: String): String {
        // Extremely simple heuristic so the HUD is never empty
        return when {
            prompt.contains("candidate_entity", ignoreCase = true) ->
                "A faint resonance is forming. The field is no longer random."
            prompt.contains("environmental_shift", ignoreCase = true) ->
                "The background has changed. Something moved the baseline."
            prompt.contains("device_interference", ignoreCase = true) ->
                "Local electronics are talking. Filtering…"
            else ->
                "The channel is quiet. Listening…"
        }
    }

    private fun String.escapeJson(): String =
        "\"" + this.replace("\\", "\\\\").replace("\"", "\\\"")
            .replace("\n", "\\n").replace("\r", "\\r") + "\""
}
