package com.spirit.scan.sensor

import kotlin.math.sqrt

/**
 * Sliding window of magnetometer + accelerometer samples.
 * Produces derived physics-style features for the real NSCB models.
 */
class CircularBuffer(private val capacity: Int = 64) {

    private data class Sample(
        val ts: Long,
        val mag: FloatArray,   // x,y,z
        val accel: FloatArray  // x,y,z
    )

    private val samples = ArrayDeque<Sample>(capacity)
    private var lastMag: FloatArray? = null
    private var lastAccel: FloatArray? = null

    fun addMag(timestamp: Long, values: FloatArray) {
        lastMag = values.copyOf(3)
        tryEmit(timestamp)
    }

    fun addAccel(timestamp: Long, values: FloatArray) {
        lastAccel = values.copyOf(3)
        tryEmit(timestamp)
    }

    private fun tryEmit(timestamp: Long) {
        val m = lastMag ?: return
        val a = lastAccel ?: return
        samples.addLast(Sample(timestamp, m, a))
        while (samples.size > capacity) samples.removeFirst()
    }

    fun ready(): Boolean = samples.size >= capacity

    fun clear() {
        samples.clear()
        lastMag = null
        lastAccel = null
    }

    // ------------------------------------------------------------------
    // Feature extraction for the real models
    // ------------------------------------------------------------------

    /**
     * 10 scalar features expected by JonesRunner.
     * Mapping is heuristic but physically motivated:
     *   x,y          → recent mag horizontal components (normalized)
     *   lam          → wavelength proxy from dominant period
     *   sigma        → mag magnitude std-dev
     *   w_period     → estimated period of oscillation
     *   lap_psi      → discrete Laplacian proxy of mag field
     *   fw_threshold → fixed firewall threshold
     *   profile_deviation → how far current mag profile is from mean
     *   dev_tol      → tolerance
     *   load_norm    → accel magnitude (device motion / “load”)
     */
    fun toJonesFeatures(): Map<String, Float> {
        require(ready())
        val mags = samples.map { it.mag }
        val accs = samples.map { it.accel }

        val mx = mags.map { it[0] }.average().toFloat()
        val my = mags.map { it[1] }.average().toFloat()
        val mz = mags.map { it[2] }.average().toFloat()
        val magMean = sqrt(mx*mx + my*my + mz*mz)

        val magMags = mags.map { sqrt(it[0]*it[0] + it[1]*it[1] + it[2]*it[2]) }
        val magStd = std(magMags)

        val last = mags.last()
        val profileDev = sqrt(
            (last[0]-mx)*(last[0]-mx) +
            (last[1]-my)*(last[1]-my) +
            (last[2]-mz)*(last[2]-mz)
        )

        // crude period estimate via zero-crossing of mag X
        val period = estimatePeriod(mags.map { it[0] })

        // discrete Laplacian-ish on last few samples
        val lap = if (mags.size >= 3) {
            val a = mags[mags.size-3]
            val b = mags[mags.size-2]
            val c = mags[mags.size-1]
            (a[0] - 2*b[0] + c[0]) + (a[1] - 2*b[1] + c[1]) + (a[2] - 2*b[2] + c[2])
        } else 0f

        val lastAcc = accs.last()
        val load = sqrt(lastAcc[0]*lastAcc[0] + lastAcc[1]*lastAcc[1] + lastAcc[2]*lastAcc[2])

        return mapOf(
            "x"                 to (mx / (magMean + 1e-6f)),
            "y"                 to (my / (magMean + 1e-6f)),
            "lam"               to period.coerceIn(0.1f, 10f),
            "sigma"             to magStd.coerceIn(0.001f, 5f),
            "w_period"          to period.coerceIn(0.1f, 10f),
            "lap_psi"           to lap,
            "fw_threshold"      to 0.55f,
            "profile_deviation" to profileDev,
            "dev_tol"           to 0.25f,
            "load_norm"         to (load / 15f).coerceIn(0f, 2f)   // ~1g ≈ 9.8
        )
    }

    /**
     * 14-dim feature vector for the SDE model.
     * Combines recent Jones-like stats + temporal derivatives.
     */
    fun toSdeFeatures(jones: JonesResult? = null): FloatArray {
        require(ready())
        val mags = samples.map { it.mag }
        val accs = samples.map { it.accel }

        val magMags = mags.map { sqrt(it[0]*it[0] + it[1]*it[1] + it[2]*it[2]) }
        val accMags = accs.map { sqrt(it[0]*it[0] + it[1]*it[1] + it[2]*it[2]) }

        val features = FloatArray(14)
        features[0]  = magMags.average().toFloat()
        features[1]  = std(magMags)
        features[2]  = accMags.average().toFloat()
        features[3]  = std(accMags)
        features[4]  = estimatePeriod(mags.map { it[0] })
        features[5]  = estimatePeriod(mags.map { it[1] })
        features[6]  = (magMags.last() - magMags.first()) / (magMags.size.coerceAtLeast(1))
        features[7]  = jones?.residual ?: 0f
        features[8]  = jones?.envelope ?: 0f
        features[9]  = jones?.routeWeight ?: 0f
        features[10] = if (jones?.inFirewall == true) 1f else 0f
        features[11] = if (jones?.harmonicOk == true) 1f else 0f
        features[12] = jones?.forcing ?: 0f
        features[13] = jones?.invariantLocal ?: 0f
        return features
    }

    private fun std(values: List<Float>): Float {
        if (values.isEmpty()) return 0f
        val mean = values.average()
        val varSum = values.sumOf { (it - mean) * (it - mean) }
        return sqrt(varSum / values.size).toFloat()
    }

    private fun estimatePeriod(series: List<Float>): Float {
        if (series.size < 8) return 1f
        val mean = series.average()
        var crossings = 0
        for (i in 1 until series.size) {
            if ((series[i-1] - mean) * (series[i] - mean) < 0) crossings++
        }
        // rough period in samples
        return if (crossings > 1) series.size.toFloat() / (crossings / 2f) else 1f
    }
}
