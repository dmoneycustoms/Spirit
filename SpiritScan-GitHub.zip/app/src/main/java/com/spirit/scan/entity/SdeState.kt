package com.spirit.scan.entity

import com.spirit.scan.ml.SdeResult

/**
 * Thin wrapper around the real SDE model output so the rest of the app
 * can stay relatively stable.
 */
data class SdeState(
    val result: SdeResult
) {
    val latent: FloatArray get() = result.toLatent()
    val isSystemOk: Boolean get() = result.isSystemOk
}
