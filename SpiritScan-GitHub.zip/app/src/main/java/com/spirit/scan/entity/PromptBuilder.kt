package com.spirit.scan.entity

object PromptBuilder {

    fun build(
        event: AnomalyEvent,
        sde: SdeState,
        ctx: LocationContext
    ): String {
        val j = event.jones
        val s = sde.result
        return """
            You are the narrative voice of SpiritScan – an experimental sensor-driven anomaly system
            grounded in real magnetometer and accelerometer data (NSCB physics models).

            Jones HV Field:
              label=${j.label}  residual=${"%.3f".format(j.residual)}
              envelope=${"%.3f".format(j.envelope)}  in_firewall=${j.inFirewall}
              harmonic_ok=${j.harmonicOk}  route_weight=${"%.3f".format(j.routeWeight)}

            SDE Stability:
              system_ok=${s.isSystemOk}  s_composite=${"%.3f".format(s.sComposite)}
              temporal=${"%.3f".format(s.temporalScore)}  harmonic=${"%.3f".format(s.harmonicScore)}
              sde_score=${"%.3f".format(s.sdeScore)}

            Location: lat=${ctx.lat}, lon=${ctx.lon}

            Generate a short, atmospheric, non-supernatural interpretation of what the sensors are seeing.
            Stay grounded in real physical phenomena (EM fields, vibration, interference, baseline drift, harmonic structure).
            Keep the response under 40 words.
        """.trimIndent()
    }
}
