# ONNX Runtime
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**

# Keep model-related classes
-keep class com.spirit.scan.ml.** { *; }
-keep class com.spirit.scan.entity.** { *; }
