# Architecture

- Sensor layer: magnetometer, accelerometer, gyro
- Jones model: anomaly classification
- SDE model: entity dynamics
- LLM: narrative generation
- HUD: live visualization and timeline
